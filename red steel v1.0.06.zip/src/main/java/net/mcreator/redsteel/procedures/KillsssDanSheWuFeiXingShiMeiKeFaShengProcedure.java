package net.mcreator.redsteel.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.projectile.WitherSkull;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.AbstractHurtingProjectile;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerLevel;

import net.mcreator.redsteel.RedsteelMod;

public class KillsssDanSheWuFeiXingShiMeiKeFaShengProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		entity.setSecondsOnFire(1);
		entity.clearFire();
		RedsteelMod.queueServerWork(20, () -> {
			if (world instanceof ServerLevel projectileLevel) {
				Projectile _entityToSpawn = new Object() {
					public Projectile getFireball(Level level, Entity shooter, double ax, double ay, double az) {
						AbstractHurtingProjectile entityToSpawn = new WitherSkull(EntityType.WITHER_SKULL, level);
						entityToSpawn.setOwner(shooter);
						entityToSpawn.xPower = ax;
						entityToSpawn.yPower = ay;
						entityToSpawn.zPower = az;
						return entityToSpawn;
					}
				}.getFireball(projectileLevel, entity, 5, 0, 0);
				_entityToSpawn.setPos(x, y, z);
				_entityToSpawn.shoot((Mth.nextInt(RandomSource.create(), 0, 1)), (Mth.nextInt(RandomSource.create(), 0, 1)), (Mth.nextInt(RandomSource.create(), 0, 1)), Mth.nextInt(RandomSource.create(), 2, 3), 0);
				projectileLevel.addFreshEntity(_entityToSpawn);
			}
		});
	}
}
