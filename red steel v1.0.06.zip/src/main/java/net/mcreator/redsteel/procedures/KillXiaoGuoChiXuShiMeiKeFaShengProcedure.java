package net.mcreator.redsteel.procedures;

public class KillXiaoGuoChiXuShiMeiKeFaShengProcedure {
	public static void execute() {
	}
}
