package net.mcreator.redsteel.procedures;

import net.minecraft.world.item.ItemStack;

public class FgsDangWuPinBeiHeChengHuoShaoLianShiProcedure {
	public static void execute(ItemStack itemstack) {
		itemstack.getOrCreateTag().putDouble("tag", 0);
	}
}
