package net.mcreator.redsteel.entity.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.redsteel.entity.UnkonwEntity;

public class UnkonwModel extends GeoModel<UnkonwEntity> {
	@Override
	public ResourceLocation getAnimationResource(UnkonwEntity entity) {
		return new ResourceLocation("redsteel", "animations/pysh.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(UnkonwEntity entity) {
		return new ResourceLocation("redsteel", "geo/pysh.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(UnkonwEntity entity) {
		return new ResourceLocation("redsteel", "textures/entities/" + entity.getTexture() + ".png");
	}

}
