
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.redsteel.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.redsteel.entity.UnkonwEntity;
import net.mcreator.redsteel.entity.KillsssEntity;
import net.mcreator.redsteel.entity.KillssEntity;
import net.mcreator.redsteel.RedsteelMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class RedsteelModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, RedsteelMod.MODID);
	public static final RegistryObject<EntityType<KillsssEntity>> KILLSSS = register("killsss",
			EntityType.Builder.<KillsssEntity>of(KillsssEntity::new, MobCategory.MISC).setCustomClientFactory(KillsssEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<UnkonwEntity>> UNKONW = register("unkonw",
			EntityType.Builder.<UnkonwEntity>of(UnkonwEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(256).setUpdateInterval(3).setCustomClientFactory(UnkonwEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<KillssEntity>> KILLSS = register("killss",
			EntityType.Builder.<KillssEntity>of(KillssEntity::new, MobCategory.MISC).setCustomClientFactory(KillssEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			UnkonwEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(UNKONW.get(), UnkonwEntity.createAttributes().build());
	}
}
