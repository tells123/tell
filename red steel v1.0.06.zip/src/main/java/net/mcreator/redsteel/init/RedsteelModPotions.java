
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.redsteel.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.redsteel.RedsteelMod;

public class RedsteelModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(ForgeRegistries.POTIONS, RedsteelMod.MODID);
	public static final RegistryObject<Potion> KIFF = REGISTRY.register("kiff", () -> new Potion(new MobEffectInstance(RedsteelModMobEffects.KIFFS.get(), 3600, 1, false, true)));
}
