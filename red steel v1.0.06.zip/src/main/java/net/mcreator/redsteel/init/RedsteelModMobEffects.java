
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.redsteel.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

import net.mcreator.redsteel.potion.KillMobEffect;
import net.mcreator.redsteel.potion.KiffsMobEffect;
import net.mcreator.redsteel.RedsteelMod;

public class RedsteelModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, RedsteelMod.MODID);
	public static final RegistryObject<MobEffect> KIFFS = REGISTRY.register("kiffs", () -> new KiffsMobEffect());
	public static final RegistryObject<MobEffect> KILL = REGISTRY.register("kill", () -> new KillMobEffect());
}
