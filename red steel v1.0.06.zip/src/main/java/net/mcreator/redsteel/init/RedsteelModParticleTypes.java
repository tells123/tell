
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.redsteel.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.particles.ParticleType;

import net.mcreator.redsteel.RedsteelMod;

public class RedsteelModParticleTypes {
	public static final DeferredRegister<ParticleType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, RedsteelMod.MODID);
	public static final RegistryObject<SimpleParticleType> KIFFSS = REGISTRY.register("kiffss", () -> new SimpleParticleType(true));
	public static final RegistryObject<SimpleParticleType> KILLS = REGISTRY.register("kills", () -> new SimpleParticleType(true));
}
