
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.redsteel.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.entity.decoration.PaintingVariant;

import net.mcreator.redsteel.RedsteelMod;

public class RedsteelModPaintings {
	public static final DeferredRegister<PaintingVariant> REGISTRY = DeferredRegister.create(ForgeRegistries.PAINTING_VARIANTS, RedsteelMod.MODID);
	public static final RegistryObject<PaintingVariant> PICK = REGISTRY.register("pick", () -> new PaintingVariant(64, 32));
}
