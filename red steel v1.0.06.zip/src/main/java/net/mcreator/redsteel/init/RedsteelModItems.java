
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.redsteel.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.item.Item;

import net.mcreator.redsteel.item.JItem;
import net.mcreator.redsteel.item.FgsItem;
import net.mcreator.redsteel.item.FgItem;
import net.mcreator.redsteel.item.F_gsArmorItem;
import net.mcreator.redsteel.RedsteelMod;

public class RedsteelModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, RedsteelMod.MODID);
	public static final RegistryObject<Item> FG = REGISTRY.register("fg", () -> new FgItem());
	public static final RegistryObject<Item> F_GS_ARMOR_HELMET = REGISTRY.register("f_gs_armor_helmet", () -> new F_gsArmorItem.Helmet());
	public static final RegistryObject<Item> F_GS_ARMOR_CHESTPLATE = REGISTRY.register("f_gs_armor_chestplate", () -> new F_gsArmorItem.Chestplate());
	public static final RegistryObject<Item> F_GS_ARMOR_LEGGINGS = REGISTRY.register("f_gs_armor_leggings", () -> new F_gsArmorItem.Leggings());
	public static final RegistryObject<Item> F_GS_ARMOR_BOOTS = REGISTRY.register("f_gs_armor_boots", () -> new F_gsArmorItem.Boots());
	public static final RegistryObject<Item> FGS = REGISTRY.register("fgs", () -> new FgsItem());
	public static final RegistryObject<Item> J = REGISTRY.register("j", () -> new JItem());
	public static final RegistryObject<Item> UNKONW_SPAWN_EGG = REGISTRY.register("unkonw_spawn_egg", () -> new ForgeSpawnEggItem(RedsteelModEntities.UNKONW, -16777216, -13421773, new Item.Properties()));
	// Start of user code block custom items
	// End of user code block custom items
}
