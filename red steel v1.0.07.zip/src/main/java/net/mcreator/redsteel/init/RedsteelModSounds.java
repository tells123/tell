
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.redsteel.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.redsteel.RedsteelMod;

public class RedsteelModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, RedsteelMod.MODID);
	public static final RegistryObject<SoundEvent> MSK = REGISTRY.register("msk", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("redsteel", "msk")));
	public static final RegistryObject<SoundEvent> TOKIT = REGISTRY.register("tokit", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("redsteel", "tokit")));
}
