
/*
*	MCreator note: This file will be REGENERATED on each build.
*/
package net.mcreator.redsteel.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.village.VillagerTradesEvent;
import net.minecraftforge.common.BasicItemListing;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.FORGE)
public class RedsteelModTrades {
	@SubscribeEvent
	public static void registerTrades(VillagerTradesEvent event) {
		if (event.getType() == RedsteelModVillagerProfessions.UN.get()) {
			event.getTrades().get(3).add(new BasicItemListing(new ItemStack(Items.NETHERITE_INGOT, 20), new ItemStack(Blocks.DIAMOND_BLOCK, 9), new ItemStack(RedsteelModItems.F_GS_ARMOR_HELMET.get()), 1, 888, 0.03f));
			event.getTrades().get(3).add(new BasicItemListing(new ItemStack(Blocks.EMERALD_BLOCK, 64), new ItemStack(RedsteelModItems.CHEATCORE.get()), new ItemStack(RedsteelModItems.F_GS_ARMOR_CHESTPLATE.get()), 1, 999, 0.03f));
			event.getTrades().get(1).add(new BasicItemListing(new ItemStack(Items.EMERALD, 35), new ItemStack(Blocks.EMERALD_BLOCK, 10), new ItemStack(RedsteelModItems.FG.get()), 30, 5, 0.02f));
			event.getTrades().get(3).add(new BasicItemListing(new ItemStack(Items.GOLD_INGOT, 40), new ItemStack(Blocks.DIAMOND_BLOCK, 10), new ItemStack(RedsteelModItems.F_GS_ARMOR_LEGGINGS.get()), 1, 5, 0.03f));
			event.getTrades().get(3).add(new BasicItemListing(new ItemStack(Blocks.GOLD_BLOCK, 5), new ItemStack(Blocks.EMERALD_BLOCK, 10), new ItemStack(RedsteelModItems.F_GS_ARMOR_BOOTS.get()), 1, 5, 0.03f));
			event.getTrades().get(1).add(new BasicItemListing(new ItemStack(RedsteelModItems.FG.get()),

					new ItemStack(Blocks.EMERALD_BLOCK, 6), 30, 5, 0.02f));
			event.getTrades().get(5).add(new BasicItemListing(new ItemStack(RedsteelModItems.FG.get(), 4), new ItemStack(Blocks.EMERALD_BLOCK), new ItemStack(RedsteelModItems.FGS.get()), 1, 5, 0.03f));
			event.getTrades().get(5).add(new BasicItemListing(new ItemStack(RedsteelModItems.FG.get(), 50), new ItemStack(RedsteelModItems.DIAMONDXIAN.get(), 3), new ItemStack(RedsteelModItems.J.get()), 1, 5, 0.03f));
			event.getTrades().get(2).add(new BasicItemListing(new ItemStack(RedsteelModItems.FG.get(), 7),

					new ItemStack(RedsteelModItems.UNKONW_SPAWN_EGG.get()), 1, 5, 0.02f));
			event.getTrades().get(4).add(new BasicItemListing(new ItemStack(RedsteelModItems.UNKONW_SPAWN_EGG.get()),

					new ItemStack(RedsteelModItems.FG.get(), 7), 10, 5, 0.02f));
			event.getTrades().get(4).add(new BasicItemListing(new ItemStack(RedsteelModItems.FG.get(), 21), new ItemStack(RedsteelModItems.DIAMONDGUNZI.get(), 5), new ItemStack(RedsteelModItems.CHEATCORE.get()), 10, 5, 0.01f));
		}
	}
}
